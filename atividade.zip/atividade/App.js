import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View, Image} from 'react-native';

export default function App() {
  return (
    <View style={styles.container}>
      <Text style={styles.name}>Iago Marcelo</Text>
      <StatusBar style="auto"/>
      <Image
        style={{width: 250, height: 250, marginTop: 15, borderRadius: 7}}
        source={require('./assets/IMG_9566.jpg')}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'black'
  },
  name:{
    fontSize: 30,
    fontWeight: 'bold',
    color: 'white'
  }
});
